﻿using CoreCrud.Data;
using CoreCrud.Models.Domain;
using CoreCrud.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CoreCrud.Controllers
{
    public class SignUp : Controller
    {
        private readonly MVCDemoDbContext mvcDemoDbContext;

        public SignUp(MVCDemoDbContext mvcDemoDbContext)
        {
            this.mvcDemoDbContext = mvcDemoDbContext;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(string name)
        {
            ViewBag.Message = string.Format("", name, DateTime.Now.ToString());
            return View();
        }


        [HttpGet]
        public IActionResult Signup()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Signup(SignupViewModel signupViewModel)
        {
            if (signupViewModel.Name == null)
            {
                ViewBag.Message = string.Format("Name is required");
                return View();
            }
            if (signupViewModel.Email == null)
            {
                ViewBag.Message = string.Format("Email is required");
                return View();
            }
            if (signupViewModel.password == null)
            {
                ViewBag.Message = string.Format("password is required");
                return View();
            }
            var signup = new Signup()
            {
                id = Guid.NewGuid(),
                Name = signupViewModel.Name,
                Email = signupViewModel.Email,
                password = signupViewModel.password
            };
            await mvcDemoDbContext.Signups.AddAsync(signup);
            await mvcDemoDbContext.SaveChangesAsync();
            return RedirectToAction("Signup");
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel loginViewModel)
        {
            if(loginViewModel.Email == null)
            {
                ViewBag.Message = string.Format("Email is Required");
                return View();
            }
            if (loginViewModel.password == null)
            {
                ViewBag.Message = string.Format("password is Required");
                return View();
            }
            //var Email = await mvcDemoDbContext.Signups.FindAsync(loginViewModel.Email);
            var Email = mvcDemoDbContext.Signups.
                Where(r => r.Email == loginViewModel.Email);
            var password = mvcDemoDbContext.Signups.
                Where(r => r.password == loginViewModel.password);
            //var password = await mvcDemoDbContext.Signups.FindAsync(loginViewModel.password);

            if (Email.Count() > 0 && password.Count() > 0)
            {
                return RedirectToAction("Add", "Employees");
            }

            return RedirectToAction("Login");
        }
    }
}
